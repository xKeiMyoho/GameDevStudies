using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameSFX : MonoBehaviour
{

    AudioManager SFX;


    void Start()
    {
        SFX = GameObject.FindGameObjectWithTag("Audio").GetComponent<AudioManager>();
    }

    void BrickHit()
    {
        SFX.Play("BrickHit");
    }
    
    void PaddleHit()
    {
        SFX.Play("PaddleHit");
    }
}