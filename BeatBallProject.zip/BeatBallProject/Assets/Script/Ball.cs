using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.EventSystems;


public class Ball : MonoBehaviour
{
    
    
    [SerializeField] private float speed = 40f;
    private Rigidbody ball_rigidbody;
    private Vector3 ball_velocity;
    public float HitScore;
    public int HitCombo;
    public GameObject comment;
    public GameObject comboUI;
    public TextMeshProUGUI ComboText;
    public TextMeshProUGUI ComboPointsText;
    public TextMeshProUGUI ComboCommentText;
    public int HighCombo = 0;

    [SerializeField] private float HitMultiplier;
    [SerializeField] private float RoundScore;


    void Awake()
    {
        
        comboUI.SetActive(false);
        
        comment.SetActive(false);
        HitMultiplier = 0.1f;
        HitScore = 0;
        RoundScore = 0;
        ball_rigidbody = GetComponent<Rigidbody>();
        
        ball_rigidbody.velocity = new Vector3(0, -20, 0) * speed;
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void FixedUpdate()
    {
        ball_rigidbody.velocity = ball_rigidbody.velocity.normalized * speed;
        ball_velocity = ball_rigidbody.velocity;
    }

    private void OnCollisionEnter(Collision collision)
    {
        
        
        

        if(collision.gameObject.tag == "Brick")
        {
            HitMultiplier *= 2;
            HitScore += 1;
            HitCombo += 1;
            if(HitCombo > 1)
            {
                comboUI.SetActive(true);
                
                ComboPointsText.text = "" + HitCombo + "";

                if(1 < HitCombo && HitCombo <= 3)
                {
                    comment.SetActive(true);
                    ComboCommentText.text = "dismal";
                    HighCombo = 1;                
                    if(HighCombo > PlayerPrefs.GetInt("HighCombo"))
                    {
                        PlayerPrefs.SetInt("HighCombo", 1);
                        PlayerPrefs.SetString("ScoreComment", "dismal");
                    }
                    
                }
                else if(3 < HitCombo && HitCombo <= 5)
                {
                    comment.SetActive(true);
                    ComboCommentText.text = "crazy";
                    HighCombo = 2;
                    if (HighCombo > PlayerPrefs.GetInt("HighCombo"))
                    {
                        PlayerPrefs.SetInt("HighCombo", 2);
                        PlayerPrefs.SetString("ScoreComment", "crazy");
                    }
                }
                else if(5 < HitCombo && HitCombo <= 7)
                {
                    comment.SetActive(true);
                    ComboCommentText.text = "badass";
                    HighCombo = 3;
                    if (HighCombo > PlayerPrefs.GetInt("HighCombo"))
                    {
                        PlayerPrefs.SetInt("HighCombo", 3);
                        PlayerPrefs.SetString("ScoreComment", "badass");
                    }
                }
                else if (7 < HitCombo && HitCombo <= 9)
                {
                    comment.SetActive(true);
                    ComboCommentText.text = "apocalyptic";
                    HighCombo = 4;
                    if (HighCombo > PlayerPrefs.GetInt("HighCombo"))
                    {
                        PlayerPrefs.SetInt("HighCombo", 4);
                        PlayerPrefs.SetString("ScoreComment", "apocalyptic");
                    }
                }
                else if (9 < HitCombo && HitCombo <= 11)
                {
                    comment.SetActive(true);
                    ComboCommentText.text = "savage";
                    HighCombo = 5;
                    if (HighCombo > PlayerPrefs.GetInt("HighCombo"))
                    {
                        PlayerPrefs.SetInt("HighCombo", 5);
                        PlayerPrefs.SetString("ScoreComment", "savage");
                    }
                }
                else if (11 < HitCombo && HitCombo <= 13)
                {
                    comment.SetActive(true);
                    ComboCommentText.text = "sick skills";
                    HighCombo = 6;
                    if (HighCombo > PlayerPrefs.GetInt("HighCombo"))
                    {
                        PlayerPrefs.SetInt("HighCombo", 6);
                        PlayerPrefs.SetString("ScoreComment", "sick skills");
                    }
                }
                else if (13 < HitCombo)
                {
                    comment.SetActive(true);
                    ComboCommentText.text = "smokin' sexy style";
                    HighCombo = 7;
                    if (HighCombo > PlayerPrefs.GetInt("HighCombo"))
                    {
                        PlayerPrefs.SetInt("HighCombo", 7);
                        PlayerPrefs.SetString("ScoreComment", "smokin sexy style");
                    }
                }
            }
        }
        else if (collision.gameObject.name == "Paddle")
        {
           
            comboUI.SetActive(false);
            comment.SetActive(false);
            RoundScore = HitScore * HitMultiplier;
            HitMultiplier = 1;
            HitScore = 0;
            HitCombo = 0;
            PlayerPrefs.SetInt("TotalScore", PlayerPrefs.GetInt("TotalScore") + (int)RoundScore);
            
            RoundScore = 0;
            
        }
        else if (collision.gameObject.tag == "GameOver")
        {
            comboUI.SetActive(false);
            comment.SetActive(false);
            RoundScore = HitScore * HitMultiplier;
            HitMultiplier = 1;
            HitScore = 0;
            HitCombo = 0;
            PlayerPrefs.SetInt("TotalScore", PlayerPrefs.GetInt("TotalScore") + (int)RoundScore);

            RoundScore = 0;
        }

        ball_rigidbody.velocity = Vector3.Reflect(ball_velocity*2, collision.contacts[0].normal);
    }
}
