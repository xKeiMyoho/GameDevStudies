using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Brick : MonoBehaviour
{
    public ParticleSystem ps;
    public int hits = 1;
    public int points = 10;
    public Vector3 rotator;
    public Material hitMaterial;
    
    private Animator animate;
    
    private Material orgMaterial;
    private Renderer renderer;
    

    AudioManager SFX;

    // Start is called before the first frame update
    void Awake()
    {
        
        animate = GameObject.FindGameObjectWithTag("Ball").GetComponent<Animator>();
        ParticleSystem ps = GetComponent<ParticleSystem>();
        transform.Rotate(rotator * (transform.position.x * transform.position.y)* 0.1f);
        renderer = GetComponent<Renderer>();
        orgMaterial = renderer.sharedMaterial;
        SFX = GameObject.FindGameObjectWithTag("Audio").GetComponent<AudioManager>();

    }

    // Update is called once per frame
    void Update()
    {
        transform.Rotate(rotator * Time.deltaTime);
    }

    private void OnCollisionEnter(Collision collision)
    {
        ps.Play();    
        SFX.Play("BrickHit");
        animate.Play("BallHit");
        hits--;
        //StartCoroutine(BGFade());

        //Score points
        if(hits <= 0)
        {
            //Destroy() is a predefined variable accessible to 
            Destroy(gameObject);
            
        }
        renderer.sharedMaterial = hitMaterial;
        Invoke("RestoreMaterial", 0.05f);


    }

    void RestoreMaterial()
    {
        renderer.sharedMaterial = orgMaterial;
    }

    /**IEnumerator BGFade()
    {
        ImageColor.a = 0.6f;
        BG.color = ImageColor;
        yield return new WaitForSeconds(0.05);
        ImageColor.a = 0.5f;
        BG.color = ImageColor;
    }***/
}
