using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameOver : MonoBehaviour
{

    [SerializeField] private bool ballDropped;
    // Start is called before the first frame update
    void Awake()
    {
        ballDropped = false;
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        
    }

    private void OnTriggerEnter(Collider collider)
    {
        if (collider.gameObject.tag == "Ball")
        {
            ballDropped = true;
            GameManager.GetInstance().EnterGameOverPhase(true);
            Debug.Log("BallDrop");

        }
        else
        {
            ballDropped = false;
        }
    }

}
