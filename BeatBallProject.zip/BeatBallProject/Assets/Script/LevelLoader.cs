using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.EventSystems;

public class LevelLoader : MonoBehaviour
{
    private bool brickCheck;

    public TextMeshProUGUI levelText;
    
    private int LevelNumber = 1;
    // Start is called before the first frame update
    void Start()
    {
        levelText.text = "LEVEL: " + LevelNumber;
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.tag == "Brick")
        {
            brickCheck = true;
        }
        else
        {
            LevelNumber += 1;
            levelText.text = "LEVEL: " + LevelNumber;
            GameManager.GetInstance().NextLevel(LevelNumber);
        }
    }
}
