using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.EventSystems;
using TMPro;

public class MainMenuScript : MonoBehaviour
{
    public GameObject playButton;
    

    public TextMeshProUGUI highscore;
    // Start is called before the first frame update
    void Start()
    {
        playButton.SetActive(true);
        if (PlayerPrefs.HasKey("Highscore"))
        {
            highscore.text = "high score: " + PlayerPrefs.GetInt("Highscore");
        }
        else
        {
            highscore.text = "high score: 0";
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void Play()
    {
        SceneManager.LoadScene(1);
    }

    public void Quit()
    {
        Application.Quit();
    }

    
}
