using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public GameObject ballPrefab;
    public GameObject paddlePrefab;

    public TextMeshProUGUI scoreText;
    public TextMeshProUGUI ballText;
    
    public TextMeshProUGUI totalScoreText;
    public TextMeshProUGUI scoreComment;
    

    public GameObject panelMenu;
    public GameObject panelPlay;
    public GameObject panelLevelCompleted;
    public GameObject panelGameOver;
    public GameObject level1;
    public GameObject level2;
    public GameObject level3;


    private Rigidbody ballRigidBody;
    private int ballLife;
    private static GameManager instance;
    private bool panelMenuOC = false;
    private bool gameOverPane = false;
    public enum State {  MENU, INIT, PLAY, LEVELCOMPLETED, LOADLEVEL, GAMEOVER }
    private State state; 


    public void PlayClicked()
    {
        SwitchState(State.INIT);
    }

    void Start()
    {
        
        level1.SetActive(true);
        level2.SetActive(false);
        level3.SetActive(false);
        PlayerPrefs.SetInt("HighCombo", 0);
        ballRigidBody = GameObject.FindGameObjectWithTag("Ball").GetComponent<Rigidbody>();
        panelLevelCompleted.SetActive(false);
        panelGameOver.SetActive(false);
        SwitchState(State.MENU);
        
    }

    private void Awake()
    {
        ballLife = 3;
        PlayerPrefs.SetInt("TotalScore", 0);
        ballText.text = "BALLS: " + ballLife;
        if (instance != null)
        {
            Debug.LogWarning("Found more than one Game Manager in the scene!");
        }
        instance = this;
    }

    public static GameManager GetInstance()
    {
        return instance;
    }

    public void SwitchState(State newState)
    {
        EndState();
        BeginState(newState);

    }

    void BeginState(State newState)
    {
        switch (newState)
        {
            case State.MENU:
                panelMenu.SetActive(false);
                panelMenuOC = false;
                break;
            case State.INIT:
                break;
            case State.PLAY:
                break;
            case State.LEVELCOMPLETED:
                break;
            case State.LOADLEVEL:
                break;
            case State.GAMEOVER:
                break;
        }
    }
    // Update is called once per frame
    void Update()
    {
        

        scoreText.text = "SCORE: " + PlayerPrefs.GetInt("TotalScore");

        if (Input.GetKeyDown(KeyCode.Escape) && panelMenuOC == false)
        {

            panelMenu.SetActive(true);
            panelMenuOC = true;
            PauseButton(1);
            Debug.Log("Paused!");
        }

        if(Input.GetKeyDown(KeyCode.Y) && gameOverPane == true)
        {
            SceneManager.LoadScene(1);
        }
        else if (Input.GetKeyDown(KeyCode.N) && gameOverPane == true)
        {
            SceneManager.LoadScene(0);
        }

        
        switch (state)
        {
            case State.MENU:
                break;
            case State.INIT:
                break;
            case State.PLAY:
                break;
            case State.LEVELCOMPLETED:
                break;
            case State.LOADLEVEL:
                break;
            case State.GAMEOVER:
                break;
        }
    }

    void EndState()
    {
        switch (state)
        {
            case State.MENU:
                
                break;
            case State.INIT:
                break;
            case State.PLAY:
                break;
            case State.LEVELCOMPLETED:
                break;
            case State.LOADLEVEL:
                break;
            case State.GAMEOVER:
                
                break;
        }
    }

    public void ResumeButtonUI()
    {
        panelMenu.SetActive(false);
        panelMenuOC = false;
        PauseButton(2);
        Debug.Log("Resumed!");
    }

    void PauseButton(int choice)
    {
        if(choice == 1)
        {
            Time.timeScale = 0;
        }
        else if(choice == 2){
            Time.timeScale = 1;
        }
    }

    public void EnterGameOverPhase(bool gameOverPhase)
    {
        if (gameOverPhase)
        {
            
            if (ballLife > 0)
            {
                ballPrefab.transform.position = new Vector3(0, 0, 0);
                ballRigidBody.velocity = new Vector3(0, -20, 0);
                ballLife -= 1;
                ballText.text = "BALLS: " + ballLife;
            }
            else
            {
                totalScoreText.text = "TOTAL SCORE: " + PlayerPrefs.GetInt("TotalScore");
                if (!PlayerPrefs.HasKey("Highscore"))
                {
                    PlayerPrefs.SetInt("Highscore", PlayerPrefs.GetInt("TotalScore"));
                    PlayerPrefs.Save();
                }
                else
                {
                    if(PlayerPrefs.GetInt("TotalScore") > PlayerPrefs.GetInt("Highscore"))
                    {
                        PlayerPrefs.SetInt("Highscore", PlayerPrefs.GetInt("TotalScore"));
                        PlayerPrefs.Save();
                    }
                }
                scoreComment.text = PlayerPrefs.GetString("ScoreComment");
                StartCoroutine(GameOver());
            }
            
            
        }
    }

    public void NextLevel(int level)
    {
        StartCoroutine(LevelLoader(level));
    }

    IEnumerator GameOver()
    {
        yield return new WaitForSeconds(0.5f);
        panelGameOver.SetActive(true);

        gameOverPane = true;


        ballPrefab.transform.position = new Vector3(0, -30, 0);
        ballRigidBody.velocity = new Vector3(0, 0, 0);
    }

    IEnumerator LevelLoader(int level)
    {
        if(level == 2)
        {
            level1.SetActive(false);
            level2.SetActive(true);
            yield return new WaitForSeconds(1f);
            ballPrefab.transform.position = new Vector3(0, 0, 0);
            ballRigidBody.velocity = new Vector3(0, -20, 0);
        }
        if(level == 3)
        {
            level2.SetActive(false);
            level2.SetActive(true);
            yield return new WaitForSeconds(1f);
            ballPrefab.transform.position = new Vector3(0, 0, 0);
            ballRigidBody.velocity = new Vector3(0, -20, 0);
        }

    }

    public void PlayAgain()
    {
        SceneManager.LoadScene(1);
    }
    
    public void MainMenuQuit()
    {
        SceneManager.LoadScene(0);
    }

   

}
